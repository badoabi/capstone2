import 'dart:io';
import 'package:capstone2/SignerPage.dart';
import 'package:flutter/material.dart';
import 'package:crypto/crypto.dart';


class HashSignButtons extends StatefulWidget {
  final File selectedFile;

  HashSignButtons({required this.selectedFile});

  @override
  _HashSignButtonsState createState() => _HashSignButtonsState();
}

class _HashSignButtonsState extends State<HashSignButtons> {
  bool _isHashing = false;

  void _hashDocument() {
    setState(() {
      _isHashing = true;
    });

    // Perform document hashing
    Future.delayed(Duration(seconds: 2), () {
      // Simulating hashing process
      String hashedDocument = sha256.convert(widget.selectedFile.readAsBytesSync()).toString();
      print('Document Hash: $hashedDocument');
      setState(() {
        _isHashing = false;
      });

      // Show success message
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Document Hashed'),
          content: Text('Hashed Document: $hashedDocument'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('OK'),
            ),
          ],
        ),
      );
    });
  }

  void _openSignerPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SignerPage(selectedFile: widget.selectedFile, hashedDocument: '',),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ElevatedButton(
          onPressed: _isHashing ? null : _hashDocument,
          child: Text('Hash Document'),
        ),
        SizedBox(height: 16),
        ElevatedButton(
          onPressed: _isHashing ? null : _openSignerPage,
          child: Text('Sign Document'),
        ),
      ],
    );
  }
}
