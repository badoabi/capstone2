import 'dart:io';
import 'package:capstone2/Verifier.dart';
import 'package:flutter/material.dart';
import 'package:capstone2/verifier_page.dart';

class SignerPage extends StatelessWidget {
  final File selectedFile;
  final String hashedDocument;

  SignerPage({required this.selectedFile, required this.hashedDocument});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sign Document'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Hashed Document: $hashedDocument'),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VerifierPage(selectedFile: selectedFile, hashedDocument: hashedDocument),
                  ),
                );
              },
              child: Text('Verify Document'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Go Back'),
            ),
          ],
        ),
      ),
    );
  }
}
