import 'dart:io';
import 'package:flutter/material.dart';

class VerifierPage extends StatelessWidget {
  final File selectedFile;
  final String hashedDocument;

  VerifierPage({required this.selectedFile, required this.hashedDocument});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Verifier Page'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Document Verified'),
            SizedBox(height: 16),
            Text('Selected File: ${selectedFile.path}'),
            SizedBox(height: 16),
            Text('Hashed Document: $hashedDocument'),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Go Back'),
            ),
          ],
        ),
      ),
    );
  }
}
