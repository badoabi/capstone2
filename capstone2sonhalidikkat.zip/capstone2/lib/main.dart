import 'dart:io';

import 'package:capstone2/SignerPage.dart';
import 'package:capstone2/sign_document_page.dart';
import 'package:capstone2/upload_document_page.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as path;
import 'HashSignButtons.dart';
import 'generate_keys_page.dart';
import 'hash_document_page.dart';
import 'login_page.dart';
import 'package:capstone2/SignerPage.dart' as SignerPageAlias;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final File selectedFile = File('/path/to/your/file'); // Replace with your actual file path

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Document Hashing App',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => LoginPage(),
        '/generate-keys': (context) => GenerateKeysPage(),
        '/upload-document': (context) => UploadDocumentPage(),
        '/hash-document': (context) => HashDocumentPage(),
        '/sign-document': (context) => SignerPage(selectedFile: selectedFile, hashedDocument: '',),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/hash') {
          return MaterialPageRoute(
            builder: (context) => HashSignButtons(selectedFile: selectedFile),
          );
        } else if (settings.name == '/signer') {
          return MaterialPageRoute(
            builder: (context) => SignerPageAlias.SignerPage(selectedFile: selectedFile, hashedDocument: '',),
          );
        }
        return null;
      },
    );
  }
}
